# Yunlong Lu created at 2021/12/1, advised by Wenxin Li, PKU AI Lab

# Agent part
from feature import FeatureAgent

# Model part
from model import CNNModel

# Botzone interaction
import numpy as np
import torch

def obs2response(model, obs):
    logits = model({'observation': torch.from_numpy(np.expand_dims(obs['observation'], 0)), 'action_mask': torch.from_numpy(np.expand_dims(obs['action_mask'], 0))})
    action = logits.detach().numpy().flatten().argmax()
    response = agent.action2response(action)
    return response

import sys

if __name__ == '__main__':
    import os
    
    model = CNNModel()
    # Load checkpoint from Botzone user storage (data/ directory)
    data_dir = 'data/model.pkl'
    if os.path.exists(data_dir):
        model.load_state_dict(torch.load(data_dir, map_location = torch.device('cpu')))
        # Debug output to stderr to avoid interfering with Botzone protocol
        import sys
        sys.stderr.write('Loaded checkpoint from ' + data_dir + '\n')
    else:
        # Fallback: try to load from current directory (local testing)
        pkl_files = [f for f in os.listdir('.') if f.endswith('.pkl')]
        if pkl_files:
            latest = max([int(f.split('.')[0]) for f in pkl_files])
            model.load_state_dict(torch.load('%d.pkl' % latest, map_location = torch.device('cpu')))
            import sys
            sys.stderr.write('Loaded checkpoint from epoch ' + str(latest) + '\n')
        else:
            raise RuntimeError('No checkpoint found! Please upload model to data/ directory.')
    model.train(False)
    input() # 1
    while True:
        try:
            request = input()
        except EOFError:
            break
        while not request.strip():
            try:
                request = input()
            except EOFError:
                break
        if not request.strip():
            break
        request = request.split()
        if request[0] == '0':
            seatWind = int(request[1])
            agent = FeatureAgent(seatWind)
            agent.request2obs('Wind %s' % request[2])
            print('PASS')
        elif request[0] == '1':
            agent.request2obs(' '.join(['Deal', *request[5:]]))
            print('PASS')
        elif request[0] == '2':
            obs = agent.request2obs('Draw %s' % request[1])
            response = obs2response(model, obs)
            response = response.split()
            if response[0] == 'Hu':
                print('HU')
            elif response[0] == 'Play':
                print('PLAY %s' % response[1])
            elif response[0] == 'Gang':
                print('GANG %s' % response[1])
                angang = response[1]
            elif response[0] == 'BuGang':
                print('BUGANG %s' % response[1])
            else:
                # Model predicted Pass or other invalid action, fallback to first playable tile
                valid_tiles = [k for k, v in agent.OFFSET_TILE.items() if (agent.OFFSET_ACT['Play'] + v) in agent.valid]
                if valid_tiles:
                    print('PLAY %s' % valid_tiles[0])
                else:
                    print('PASS')
        elif request[0] == '3':
            p = int(request[1])
            if request[2] == 'DRAW':
                agent.request2obs('Player %d Draw' % p)
                zimo = True
                print('PASS')
            elif request[2] == 'GANG':
                if p == seatWind and angang:
                    agent.request2obs('Player %d AnGang %s' % (p, angang))
                elif zimo:
                    agent.request2obs('Player %d AnGang' % p)
                else:
                    agent.request2obs('Player %d Gang' % p)
                print('PASS')
            elif request[2] == 'BUGANG':
                obs = agent.request2obs('Player %d BuGang %s' % (p, request[3]))
                if p == seatWind:
                    print('PASS')
                else:
                    response = obs2response(model, obs)
                    if response == 'Hu':
                        print('HU')
                    else:
                        print('PASS')
            else:
                zimo = False
                if request[2] == 'CHI':
                    agent.request2obs('Player %d Chi %s' % (p, request[3]))
                elif request[2] == 'PENG':
                    agent.request2obs('Player %d Peng' % p)
                obs = agent.request2obs('Player %d Play %s' % (p, request[-1]))
                if p == seatWind:
                    print('PASS')
                else:
                    response = obs2response(model, obs)
                    response = response.split()
                    if response[0] == 'Hu':
                        print('HU')
                    elif response[0] == 'Pass':
                        print('PASS')
                    elif response[0] == 'Gang':
                        print('GANG')
                        angang = None
                    elif response[0] in ('Peng', 'Chi'):
                        obs = agent.request2obs('Player %d '% seatWind + ' '.join(response))
                        response2 = obs2response(model, obs)
                        print(' '.join([response[0].upper(), *response[1:], response2.split()[-1]]))
                        agent.request2obs('Player %d Un' % seatWind + ' '.join(response))
        print('>>>BOTZONE_REQUEST_KEEP_RUNNING<<<')
        sys.stdout.flush()